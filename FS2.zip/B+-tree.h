#pragma once
#include <iostream>
#include <fstream>
using namespace std;

const unsigned maxRecNum = 4096 / 32;

struct Entry {
	union {
		BpTreeNode *sNode;
		int bNum;
	};
	int value;
};

struct BpTreeNode {
	int count;
	Entry entry[maxRecNum];
	BpTreeNode *p;
};

class BpTree {
private:
	BpTreeNode *root;
public:
	void traverse(BpTreeNode *p);
	void sort(int *p, int n);
	void insert(int a);
};
