#include "B+-tree.h"

const unsigned numOfRec;

struct BpTreeNode
{
	int *data;
	BpTreeNode **child_ptr;
	bool leaf;
	int n;
}*root = NULL, *np = NULL, *x = NULL;

BpTreeNode* init()
{
	int i;
	np = new BpTreeNode;
	np->data = new int[numOfRec];
	np->child_ptr = new BpTreeNode*[numOfRec + 1];
	np->leaf = true;
	np->n = 0;
	for (i = 0; i < numOfRec + 1; i++) {
		np->child_ptr[i] = NULL;
	}
	return np;
}

void sort(int *p, int n)
{
	int i, j, temp;
	for (i = 0; i < n; i++)
	{
		for (j = i; j <= n; j++)
		{
			if (p[i] > p[j])
			{
				temp = p[i];
				p[i] = p[j];
				p[j] = temp;
			}
		}
	}
}

int split_child(BpTreeNode *x, int i)
{
	int j, mid;
	BpTreeNode *np1, *np3, *y;
	np3 = init();
	np3->leaf = true;
	if (i == -1)
	{
		mid = x->data[numOfRec / 2];
		x->data[numOfRec / 2] = 0;
		x->n--;
		np1 = init();
		np1->leaf = false;
		x->leaf = true;
		for (j = (numOfRec/2) + 1; j < numOfRec; j++)
		{
			np3->data[j - (numOfRec + 1)] = x->data[j];
			np3->child_ptr[j - (numOfRec/2+1)] = x->child_ptr[j];
			np3->n++;
			x->data[j] = 0;
			x->n--;
		}
		for (j = 0; j < (numOfRec + 1); j++)
		{
			x->child_ptr[j] = NULL;
		}
		np1->data[0] = mid;
		np1->child_ptr[np1->n] = x;
		np1->child_ptr[np1->n + 1] = np3;
		np1->n++;
		root = np1;
	}
	else
	{
		y = x->child_ptr[i];
		mid = y->data[numOfRec/2];
		y->data[numOfRec/2] = 0;
		y->n--;
		for (j = (numOfRec / 2 + 1); j < numOfRec; j++)
		{
			np3->data[j - numOfRec / 2 + 1)] = y->data[j];
			np3->n++;
			y->data[j] = 0;
			y->n--;
		}
		x->child_ptr[i + 1] = y;
		x->child_ptr[i + 1] = np3;
	}
	return mid;
}
void insert(int a)
{
	int i, temp;
	x = root;
	if (x == NULL)
	{
		root = init();
		x = root;
	}
	else
	{
		if (x->leaf == true && x->n == numOfRec)
		{
			temp = split_child(x, -1);
			x = root;
			for (i = 0; i < (x->n); i++)
			{
				if ((a > x->data[i]) && (a < x->data[i + 1]))
				{
					i++;
					break;
				}
				else if (a < x->data[0])
				{
					break;
				}
				else
				{
					continue;
				}
			}
			x = x->child_ptr[i];
		}
		else
		{
			while (x->leaf == false)
			{
				for (i = 0; i < (x->n); i++)
				{
					if ((a > x->data[i]) && (a < x->data[i + 1]))
					{
						i++;
						break;
					}
					else if (a < x->data[0])
					{
						break;
					}
					else
					{
						continue;
					}
				}
				if ((x->child_ptr[i])->n == 5)
				{
					temp = split_child(x, i);
					x->data[x->n] = temp;
					x->n++;
					continue;
				}
				else
				{
					x = x->child_ptr[i];
				}
			}
		}
	}
	x->data[x->n] = a;
	sort(x->data, x->n);
	x->n++;
}